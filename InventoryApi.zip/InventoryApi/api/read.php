<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
$pathForDb="C:\xampp\htdocs\InventoryApi\config\database.php";
$pathForItemClass="C:\xampp\htdocs\InventoryApi\class\item.php";
require $pathForDb;
require $pathForItemClass;

$database = new Database();

$db = $database->getConnection();
$items = new Item($db);
$records = $items->getItems();
$itemCount = $records->num_rows;
echo json_encode($itemCount);
if($itemCount > 0){
$itemArr = array();
$itemArr["body"] = array();
$itemArr["itemCount"] = $itemCount;
while ($row = $records->fetch_assoc())
{
array_push($itemArr["body"], $row);
}
echo json_encode($itemArr);
}
else{
http_response_code(404);
echo json_encode(
array("message" => "No record found.")
);
}
?>