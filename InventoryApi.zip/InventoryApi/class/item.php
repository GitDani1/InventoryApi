<?php
    class Item{
        // Connection
        private $db;
        // Table
        private $db_table = "item";
        // Columns
        public $id;
        public $name;
        public $quantity;
        public $price;
        public $category;
        // Db connection
        public function __construct($db){
            $this->db = $db;
        }
       // GET ALL
public function getItems(){
    $sqlQuery = "SELECT id, name, quantity, price, category FROM " . $this->db_table . "";
    $result = $this->db->query($sqlQuery);
    return $result;
    }
    
    // CREATE
    public function createItems(){
    // sanitize
    $this->name=htmlspecialchars(strip_tags($this->name));
    $this->quantity=htmlspecialchars(strip_tags($this->quantity));
    $this->price=htmlspecialchars(strip_tags($this->price));
    $this->category=htmlspecialchars(strip_tags($this->category));
    $sqlQuery = "INSERT INTO
    ". $this->db_table ." SET name = '".$this->name."',
    quantity = '".$this->quantity."',
    price = '".$this->price."',category = '".$this->category."'";
    $this->db->query($sqlQuery);
    if($this->db->affected_rows > 0){
    return true;
    }
    return false;
    }
    
    // UPDATE
    public function getSingleItem(){
    $sqlQuery = "SELECT id, name, quantity, price, category FROM
    ". $this->db_table ." WHERE id = ".$this->id;
    $record = $this->db->query($sqlQuery);
    $dataRow=$record->fetch_assoc();
    $this->name = $dataRow['name'];
    $this->quantity = $dataRow['quantity'];
    $this->price = $dataRow['price'];
    $this->category = $dataRow['category'];
    }
    
    // UPDATE
    public function updateItems(){
    $this->name=htmlspecialchars(strip_tags($this->name));
    $this->quantity=htmlspecialchars(strip_tags($this->quantity));
    $this->price=htmlspecialchars(strip_tags($this->price));
    $this->category=htmlspecialchars(strip_tags($this->category));
    $this->id=htmlspecialchars(strip_tags($this->id));
    
    $sqlQuery = "UPDATE ". $this->db_table ." SET name = '".$this->name."',
    quantity = '".$this->quantity."',
    price = '".$this->price."',category = '".$this->category."'
    WHERE id = ".$this->id;
    
    $this->db->query($sqlQuery);
    if($this->db->affected_rows > 0){
    return true;
    }
    return false;
    }
    
    // DELETE
    function deleteItems(){
    $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ".$this->id;
    $this->db->query($sqlQuery);
    if($this->db->affected_rows > 0){
    return true;
    }
    return false;
    }
    }
    ?>